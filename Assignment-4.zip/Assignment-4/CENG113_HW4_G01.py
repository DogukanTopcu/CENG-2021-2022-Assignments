# CENG113 HW4 TEMPLATE
# AUTHOR: SAMET TENEKECI
# DATE: 27/12/2021

# MODIFY AND RENAME THIS FILE FOR YOUR ASSIGNMENT
# EXAMPLE FILE NAMING: CENG113_HW4_G01.py OR CENG_113_HW4_G25.py
# WRITE STUDENT IDS, NAMES & SURNAMES OF THE GROUP MEMBERS AT THE TOP
# SUBMIT ONLY THIS FILE AND ONLY ONCE FOR YOUR GROUP


from typing import Sequence
import csv

def read_genes(file_path):
    with open(file_path) as f:
        count = 1
        key = 0
        gene_dict = {}
        for line in f.read().splitlines():
            if count % 2 == 1:
                key = line
                count += 1
            elif count % 2 == 0:
                gene_dict[key] = line
                count += 1
    return gene_dict



def get_fragments(gene_dict, frag_len = 50):
    frag_dict = {}
    for key in gene_dict:
        chromosome_id = key.split("|")[0]
        indexes = key.split("|")[1]
        starting_index = indexes.split("-")[0]
        sequence = gene_dict.get(key);
        fragments = [sequence[i:i+frag_len] for i in range(0, len(sequence), frag_len)]

        for fragment in fragments:
            if len(fragment) == frag_len:
                ending_index = int(starting_index) + frag_len
                ending_index = str(ending_index)

                header = str(chromosome_id) + "|" + str(starting_index) + "-" + str(ending_index)
                frag_dict[header] = fragment

                starting_index = int(starting_index)
                ending_index = int(ending_index)
                starting_index = ending_index
                ending_index += frag_len
            
    return frag_dict


def filter_frags(frag_dict, threshold = 0.7):
    def get_similarity(s1, s2):
        # STEP 3.a
        s1_characters = []
        s2_characters = []
        for str in s1:
            s1_characters.append(str)
        for str in s2:
            s2_characters.append(str)
        
        count = 0
        for i in range(len(s1_characters)):
            if s1_characters[i] == s2_characters[i]:
                count +=1
        similarity = count/len(s1_characters)
        
        return similarity
    
    # STEP 3.b
    dissimilar_frag_dict = {}

    for i in range(len(frag_dict)):
        for j in range(i + 1, len(frag_dict)):
            frag1 = list(frag_dict.items())[i][1]
            frag2 = list(frag_dict.items())[j][1]

            similarity = get_similarity(frag1, frag2)

            

            if similarity >= threshold:
                print(similarity)
                header = list(frag_dict.items())[i][0]
                dissimilar_frag_dict[header] = frag1
            else: 
                header1 = list(frag_dict.items())[i][0]
                header2 = list(frag_dict.items())[j][0]
                dissimilar_frag_dict[header1] = frag1
                dissimilar_frag_dict[header2] = frag2
        
    return dissimilar_frag_dict


def get_sentences(dissimilar_frag_dict):
    def generate_kmers(seq, k):
        # STEP 4.a
        new_str = ""
        for i in range(0, len(seq)):
            x = seq[i:k+i]
            if len(x) == 4:
                new_str += x + " "
        
        return new_str

    
    # STEP 4.b
    for key in dissimilar_frag_dict:
        dissimilar_frag_dict[key] = generate_kmers(dissimilar_frag_dict[key], 4)
        print(dissimilar_frag_dict[key])

    return dissimilar_frag_dict


def clean_dict(sentences_dict):
    def clean_sentence(sentence):
        # STEP 5.a
        new_list = []
        x = sentence.split(" ")
        for i in x:
            isExist = False
            for j in new_list:
                if i == j:
                    isExist = True
            if isExist == False:
                new_list.append(i)
        
        return_sentence = ""
        for i in new_list:
            return_sentence += i + " "

        return return_sentence


    # STEP 5.b
    for key in sentences_dict:
        sentences_dict[key] = clean_sentence(sentences_dict[key])
    
    return sentences_dict


def write_genes(file_path, clean_sentences_dict):
    # STEP 6
    with open(file_path, "w", newline='') as file:
        writer = csv.writer(file)
        writer.writerow(["fragment_id", "sentence", "sentence_length", "number_of_words"])
        for key in clean_sentences_dict:
            x = clean_sentences_dict[key].split(" ")
            writer.writerow([key, clean_sentences_dict[key], len(clean_sentences_dict[key]), len(x)])



def main():
    x = read_genes("input.txt")
    y = get_fragments(x)
    z = filter_frags(y)
    t = get_sentences(z)
    k = clean_dict(t)
    write_genes("output.csv", k)

    # STEP 7: Runs required steps and prints data statistics

        # 1) read genes from input.txt
        #    print the number of genes -> Expected output: 115
        # 2) get fragments for genes read
        #    print the number of fragments -> Expected output: 1293
        # 3) filter out similar fragments
        #    print the number of dissimilar fragments -> Expected output: 1286
        # 4) get sentences for dissimilar fragments
        #    print the number of words in a sentence -> Expected output: 46
        # 5) remove duplicate words in sentences
        #    print the total number of words removed -> Expected output: 8194
        # 6) write sentences into output.csv

    # DO NOT SCAN OR PRINT EXTRA INFORMATION. JUST THE STATS LISTED ABOVE.


main()
