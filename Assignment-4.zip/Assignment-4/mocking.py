#seq = "ASDFGHJKLZXCVBNM"
#k = 4
"""
def toFour(seq, k):
    new_str = ""
    for i in range(0, len(seq)):
        x = seq[i:k+i]
        if len(x) == 4:
            new_str += x + " "

    return new_str    


dict = {
    "key-1" : "value-1c",
    "key-2" : "value-2c",
    "key-3" : "value-3c",
    "key-4" : "value-4c",
    "key-5" : "value-5c",
    "key-6" : "value-6c"
}

for key in dict:
    dict[key] = toFour(dict[key], 4)
    print(dict[key])


sentence = "abcd abcd bcde cdef defg defg defg efgh fghj"
"""

def func(sentence):
    new_list = []
    x = sentence.split(" ")
    for i in x:
        isExist = False
        for j in new_list:
            if i == j:
                isExist = True
        if isExist == False:
            new_list.append(i)

    sentence1 = ""
    for i in new_list:
        sentence1 += i + " "

    return sentence1


dict = {
    "key-1" : "abcd cdef defg defg defg efgh fghj",
    "key-2" : "abcd bcde bcde cdef cdef defg defg defg efgh fghj",
    "key-3" : "abcd abcd bcde cdef defg defg defg efgh ",
    "key-4" : "abcd abcd bcde cdef defg fghj",
    "key-5" : "abcd abcd bcde cdef defg defg defg efgh fghj",
    "key-6" : "abcd abcd bcde cdef cdef cdef defg defg defg efgh fghj"
}
list = ["x", "y", "z"]
print(len(list))
for key in dict:
    dict[key] = func(dict[key])
    print(len(dict[key]))
